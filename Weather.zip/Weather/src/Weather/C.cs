﻿namespace Weather.DAL.Repository
{
    public class C
    {
    }
}