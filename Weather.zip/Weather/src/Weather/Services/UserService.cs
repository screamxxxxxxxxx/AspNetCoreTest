﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Weather.DAL.DbModels;
using Weather.DAL.Repository.Interfaces;
using Weather.Services.Interfaces;
using Weather.Models.Admin;
using Microsoft.Extensions.Logging;
using Weather.Models.Log;

namespace Weather.Services
{
    public class UserService : IUserService
    {
        private ICitiesRepository citiesRepository;
        private IUsersCitiesRepository cityUserRepository;
        private IUserRepository userRepository;
        private ILogger logger;
        public UserService(ICitiesRepository citiesRepository, IUsersCitiesRepository cityUserRepository, IUserRepository userRepository, ILoggerFactory loggerFactory)
        {
            this.logger = loggerFactory.CreateLogger("");
            this.userRepository = userRepository;
            this.cityUserRepository = cityUserRepository;
            this.citiesRepository = citiesRepository;
        }

        public IEnumerable<UserVeiwModel> GetAllUsersViewModel()
        {
            return this.userRepository.GetAllUsers().Select(x => new UserVeiwModel {Name = x.UserName, Id = x.Id});
        }

        public IEnumerable<City> GetAssignedUserCities(string userId)
        {
            return this.citiesRepository.GetAssignedCitiesForUser(userId);
        }

        public IEnumerable<City> GetAvaliableForAssignCitiesForUSer(string userId)
        {
            return this.citiesRepository.GetAvaliableForAssignCitiesForUser(userId);
        }

        public void SubscribeToCity(string cityName, string userId)
        {
            var assignedCitiesNames = this.GetAssignedUserCities(userId).Select(x => x.Name);

            if(assignedCitiesNames.Contains(cityName))
            {
                return;
            }

            var city = this.citiesRepository.FindByName(cityName);

            if(city == null)
            {
                return;
            }

            var cityUser = new CityUser {
                CityId = city.Id,
                UserId = userId
            };

            this.cityUserRepository.CreateCityUser(cityUser);

            this.logger.Log(default(LogLevel),  default(EventId), new LogModel {
                UserId = userId,
                Message = $"User subscribed to city {cityName}",
                ActionType = Enums.LogActionTypes.UserSubscribedToCity
            }, null, null);         
        }

        public void UnSubscribeFromCity(string cityName, string userId)
        {
            var city = this.citiesRepository.FindByName(cityName);

            var cityUser = this.cityUserRepository.Find(x => city != null && x.CityId == city.Id && x.UserId == userId);

            if(cityUser != null)
            {
                this.cityUserRepository.Delete(cityUser);
            }

            this.logger.Log(default(LogLevel), default(EventId), new LogModel
            {
                UserId = userId,
                Message = $"User unsubscribed from city {cityName}",
                ActionType = Enums.LogActionTypes.UserUnSubscripedFromCity
            }, null, null);
        }
    }
}
