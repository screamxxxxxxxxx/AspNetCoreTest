﻿using MailKit.Net.Smtp;
using MimeKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.Services.Interfaces;

namespace Weather.Services
{
    public class EmailSender : IEmailSender
    {
        public Task SendEmailAsync(string email, string subject, string message)
        {
            return Task.Run(() =>
            {
                var messageToSend = new MimeMessage();
                messageToSend.From.Add(new MailboxAddress("Scr", "s@gmail.com"));
                messageToSend.To.Add(new MailboxAddress("Sen", email));
                messageToSend.Subject = subject;
                var bodyBuilder = new BodyBuilder();
                bodyBuilder.HtmlBody = message;
                messageToSend.Body = bodyBuilder.ToMessageBody();

                using (var client = new SmtpClient())
                {
                    client.Connect("smtp.gmail.com", 465, true);
                    client.AuthenticationMechanisms.Remove("XOAUTH2");
                    client.Authenticate("email", "password");
                    // Note: since we don't have an OAuth2 token, disable 	// the XOAUTH2 authentication mechanism.     client.Authenticate("anuraj.p@example.com", "password");
                    client.Send(messageToSend);
                    client.Disconnect(true);
                }
            });
                  
        }
    }
}
