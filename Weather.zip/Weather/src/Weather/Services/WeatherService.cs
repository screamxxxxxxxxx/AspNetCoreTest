﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.Services.Interfaces;
using Weather.Services.Models;
using System.Net.Http;
using Newtonsoft.Json;

namespace Weather.Services
{
    public class WeatherService : IWeatherAPIService
    {
        public async Task<CityWeatherInfo>  GetWeatherInCity(string cityName)
        {
            CityWeatherInfo result = new CityWeatherInfo(); ;

            using (var client = new HttpClient())
            {            
                    client.BaseAddress = new Uri($"http://api.openweathermap.org/data/2.5/weather?q={cityName}&APPID=a060e0119ab0a37ac2f289f25ac9da58");
                    client.DefaultRequestHeaders.Accept.Clear();
                    var response = await client.GetAsync(client.BaseAddress);
                    response.EnsureSuccessStatusCode(); // Throw in not success
                    var stringResponse = await response.Content.ReadAsStringAsync();
                    var x = JsonConvert.DeserializeObject<dynamic>(stringResponse)["main"];

                result.temp = x["temp"];
                result.temp_max = x["temp_max"];
                result.temp_min = x["temp_min"];
                result.pressure = x["pressure"];
                result.humidity = x["humidity"];              
            }

            return result;
        }
    }
}
