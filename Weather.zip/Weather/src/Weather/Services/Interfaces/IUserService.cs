﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.DAL.DbModels;
using Weather.Models.Admin;

namespace Weather.Services.Interfaces
{
    public interface IUserService
    {
        IEnumerable<City> GetAssignedUserCities(string userId);

        IEnumerable<City> GetAvaliableForAssignCitiesForUSer(string userId);

        void SubscribeToCity(string cityName, string userId);

        void UnSubscribeFromCity(string cityName, string userId);

        IEnumerable<UserVeiwModel> GetAllUsersViewModel();
    }
}
