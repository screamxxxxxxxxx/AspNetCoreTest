﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Weather.Services.Interfaces
{
    public interface IDbInitializer
    {
        Task Seed(IServiceProvider serviceProvider, IConfigurationRoot configuration);
    }
}
