﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.Services.Models;

namespace Weather.Services.Interfaces
{
    public interface IWeatherAPIService
    {
        Task<CityWeatherInfo> GetWeatherInCity(string cityName);      
    }
}
