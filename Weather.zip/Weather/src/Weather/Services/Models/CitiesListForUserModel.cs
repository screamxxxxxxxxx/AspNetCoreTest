﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Weather.Services.Models
{
    public class CitiesListForUserModel
    {
        public List<string> AssignedCities { get; set; }

        public List<string> AvaliableCities { get; set; }
    }
}
