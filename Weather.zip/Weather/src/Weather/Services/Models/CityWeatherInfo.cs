﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Weather.Services.Models
{
    public class CityWeatherInfo
    {
        public string humidity { get; set; }

        public string temp { get; set; }

        public string pressure { get; set; }

        public string temp_max  { get; set; }

        public string temp_min  { get; set; }
    }
}
