﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.DAL.Repository.Interfaces;

namespace Weather.Services.Logger
{
    public class DbLoggerProvider : ILoggerProvider
    {
        private ILogRepository logRepositoy;
        public DbLoggerProvider(ILogRepository logRepositoy)
        {
            this.logRepositoy = logRepositoy;
        }

        public ILogger CreateLogger(string categoryName)
        {
            return new CustomDbLogger(logRepositoy);
        }

        public void Dispose()
        {
            
        }
    }
}
