﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.DAL.DbModels;
using Weather.DAL.Repository.Interfaces;
using Weather.Enums;
using Weather.Models.Log;
using Weather.Services.Interfaces;

namespace Weather.Services
{
    public class CustomDbLogger : ILogger
    {
        private bool isEnabled = true;
        private ILogRepository logRepository;

        public CustomDbLogger(ILogRepository logRepository)
        {
            this.logRepository = logRepository;
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return null;
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return isEnabled;
        }

        private string GetExceptionDetails(Exception e)
        {
            var message = e.Message;
            var maxNested = 5;

            while(e.InnerException != null && maxNested > 0)
            {
                maxNested-=1;
                e = e.InnerException;
                message += $"----InnerException----: {e.Message}";
            }

            return message;
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            if(exception != null)
            {
                var message = this.GetExceptionDetails(exception);
                try
                {
                    isEnabled = false;
                    this.LogToDatabase("", message, LogActionTypes.Error);
                    isEnabled = true;
                }
                catch(Exception e)
                {
                    isEnabled = false;
                }                                      
            }
            else
            {
                var logModel = state as LogModel;

                if (logModel != null)
                {
                    this.LogToDatabase(logModel.UserId, logModel.Message, logModel.ActionType);
                }
            }          
        }

        private void LogToDatabase(string userId, string message, LogActionTypes action)
        {
            var log = new Log()
            {
                UserId = userId,
                Date = DateTime.Now.ToUniversalTime(),
                Message = message,
                ActionType = (int)action
            };

            this.logRepository.AddLog(log);
        }
    }
}
