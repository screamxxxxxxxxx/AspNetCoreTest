﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.Enums;

namespace Weather.Models.Log
{
    public class LogModel
    {
        public string UserId { get; set; }

        public string Message { get; set; }

        public LogActionTypes ActionType { get; set; }
    }
}
