﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Weather.Models.Admin
{
    public class UserVeiwModel
    {
        public string Name { get; set; }

        public string Id { get; set; }
    }
}
