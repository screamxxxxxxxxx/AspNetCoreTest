﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Weather.Helper
{
    public static class CommandLineParamsHolder
    {
        public static string [] Args { get; set; }
    }
}
