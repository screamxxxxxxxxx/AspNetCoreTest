﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Weather.Helper
{
    public static class ConnentionStringNameHelper
    {
        public static string GetConnectionStringName(string keyParam)
        {
            if (string.IsNullOrEmpty(keyParam) || keyParam != "mySql")
            {
                return "SqlConnection";
            }
            else
            {
                return "MySqlConnection";
            }
        }
    }
}
