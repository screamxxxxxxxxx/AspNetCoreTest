﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Weather.TagHelpers
{
    public class AppVersionTagHelper : TagHelper
    {
        private string AssemblyVersion;

        public AppVersionTagHelper()
        {
            AssemblyVersion = System.Reflection.Assembly.GetEntryAssembly().GetName().Version.ToString();
        }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "span";
            output.Content.SetContent(AssemblyVersion);
            output.TagMode = TagMode.StartTagAndEndTag;
        }
    }
}
