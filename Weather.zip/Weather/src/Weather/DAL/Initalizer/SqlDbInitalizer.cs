﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.DAL.DbContexts;
using Weather.DAL.DbModels;
using Weather.Services.Interfaces;

namespace Weather.DAL.Initalizer
{
    public  class SqlDbInitalizer : IDbInitializer
    {
        public  async Task Seed(IServiceProvider serviceProvider, IConfigurationRoot configuration)
        {                      
                var userManager = serviceProvider.GetRequiredService<UserManager<IdentityUser>>();
                var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
                var environment = serviceProvider.GetRequiredService<IHostingEnvironment> ();               
                  
            using (var context = new WeatherContext(
                serviceProvider.GetRequiredService<DbContextOptions<WeatherContext>>()))
            {
                context.Database.EnsureCreated();
                if(context.Cities.Any())
                {
                    return;
                }

                var city = new City()
                {
                    Name = "London"
                };

                context.Cities.Add(city);

                city = new City
                {
                    Name = "Kiev"
                };

                context.Add(city);

                city = new City
                {
                    Name = "Pekin"
                };

                context.Cities.Add(city);

                city = new City {
                    Name = "Istanbul"
                };

                context.Add(city);

                city = new City {
                    Name = "Tokio"
                };

                context.Add(city);
              
                context.SaveChanges();                 
            }

            if (!await userManager.Users.AnyAsync())
            {

                var userEmail = "admin@gmail.com";
                var userPass = "12345678Ps*";

                if (environment.IsStaging())
                {
                    userEmail = configuration["AdminEmail"];
                    userPass = configuration["AdminPass"];
                }

                await roleManager.CreateAsync(new IdentityRole
                {
                    Name = "Admin",
                });

                await userManager.CreateAsync(new IdentityUser
                {
                    UserName = userEmail,
                    Email = userEmail,
                }, userPass);

                var admin = await userManager.Users.FirstAsync(x => x.UserName == userEmail);
                var role = await roleManager.Roles.FirstAsync(x => x.Name == "Admin");

                admin.Roles.Add(new IdentityUserRole<string>
                {
                    UserId = admin.Id,
                    RoleId = role.Id
                });

                await userManager.UpdateAsync(admin);
            }
        }
    }
}
