﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.DAL.DbContexts;
using Weather.DAL.DbModels;
using Weather.DAL.Repository.Interfaces;

namespace Weather.DAL.Repository
{
    public class CityUserRepository<C> : Repository<CityUser, C>, IUsersCitiesRepository where C : DbContext
    {
        public CityUserRepository(C context) : base(context)
        {
        }

        public void CreateCityUser(CityUser cityUser)
        {
            this.AddEntity(cityUser);
            this.SaveChanges();
        }

        public void Delete(CityUser cityUser)
        {
            this.DeleteEntity(cityUser);
            this.SaveChanges();
        }

        public CityUser Find(Func<CityUser, bool> predicate)
        {
            return this.Context.Set<CityUser>().FirstOrDefault(predicate);
        }
    }
}
