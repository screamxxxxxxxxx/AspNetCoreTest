﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.DAL.DbContexts;
using Weather.DAL.DbModels;
using Weather.DAL.Repository.Interfaces;

namespace Weather.DAL.Repository
{
    public class CityRepository<C> : Repository<City, C>, ICitiesRepository where C: DbContext
    {
        public CityRepository(C context) : base(context)
        {
        }

        public City FindByName(string name)
        {
            return this.Context.Set<City>().FirstOrDefault(x => x.Name == name);
        }

        public IEnumerable<City> GetAssignedCitiesForUser(string userId)
        {
            var usersCitiesIds = this.Context.Set<CityUser>().Where(x => x.UserId == userId).Select(x => x.CityId).ToArray();

            return this.Filter(x => usersCitiesIds.Contains(x.Id));
        }

        public IEnumerable<City> GetAvaliableForAssignCitiesForUser(string userId)
        {
            var usersCitiesIds = this.Context.Set<CityUser>().Where(x => x.UserId == userId).Select(x => x.CityId).ToArray();

            return this.Filter(x => !usersCitiesIds.Contains(x.Id));
        }
    }
}
