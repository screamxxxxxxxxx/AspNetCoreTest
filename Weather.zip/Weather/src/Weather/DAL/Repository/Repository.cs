﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.DAL.DbContexts;
using Weather.DAL.Repository.Interfaces;

namespace Weather.DAL.Repository
{
    public abstract class Repository<T, C> : IRepository<T, C> where T : class where C : DbContext
    {
        private C _context;

        public Repository(C context)
        {
            this._context = context;
        }

        public C Context
        {
            get
            {
                return this._context;
            }
        }

        public void AddEntity(T entity)
        {
            this._context.Set<T>().Add(entity);
        }

        public void DeleteEntity(T entity)
        {
            this._context.Set<T>().Remove(entity);
        }

        public IQueryable<T> Filter(Func<T, bool> predicate)
        {
            return this._context.Set<T>().Where(predicate).AsQueryable();
        }

        public IQueryable<T> GetAllEntities()
        {
            return this._context.Set<T>().AsQueryable();
        }

        public void SaveChanges()
        {
            this._context.SaveChanges();
        }

        public void UpdateEntity(T entity)
        {
            this._context.Set<T>().Update(entity);
        }
    }
}
