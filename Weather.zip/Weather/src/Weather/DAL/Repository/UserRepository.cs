﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Weather.DAL.DbContexts;
using Weather.DAL.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Weather.DAL.Repository
{
    public class UserRepository<C> : Repository<IdentityUser, C>, IUserRepository where C: DbContext
    {
        public UserRepository(C context) : base(context)
        {
        }

        public IEnumerable<IdentityUser> GetAllUsers()
        {
            return this.GetAllEntities();
        }

        public IdentityUser GetUserWithNameByEmail(string email)
        {
            return this.Context.Set<IdentityUser>().FirstOrDefault(x => x.UserName == email);
        }
    }
}
