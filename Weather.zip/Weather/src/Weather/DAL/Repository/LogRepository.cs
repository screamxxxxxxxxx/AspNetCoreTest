﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.DAL.DbContexts;
using Weather.DAL.DbModels;
using Weather.DAL.Repository.Interfaces;

namespace Weather.DAL.Repository
{
    public class LogRepository<C> : Repository<Log, C>, ILogRepository where C: DbContext
    {
        public LogRepository(C context) : base(context)
        {
        }

        public void AddLog(Log log)
        {
            this.AddEntity(log);
            this.SaveChanges();
        }

        public IEnumerable<Log> GetAllLogs()
        {
            return this.GetAllEntities();
        }
    }
}
