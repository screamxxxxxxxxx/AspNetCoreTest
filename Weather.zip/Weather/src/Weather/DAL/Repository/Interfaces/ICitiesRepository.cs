﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.DAL.DbModels;
using Weather.DAL.Repository.Interfaces;

namespace Weather.DAL.Repository.Interfaces
{
    public interface ICitiesRepository
    {
        City FindByName(string name);

        IEnumerable<City> GetAssignedCitiesForUser(string userId);

        IEnumerable<City> GetAvaliableForAssignCitiesForUser(string userId);
    }
}
