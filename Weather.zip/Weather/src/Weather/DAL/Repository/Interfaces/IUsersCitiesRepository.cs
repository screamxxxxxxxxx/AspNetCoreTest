﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.DAL.DbModels;

namespace Weather.DAL.Repository.Interfaces
{
    public interface IUsersCitiesRepository
    {
        void CreateCityUser(CityUser cityUser);

        void Delete(CityUser cityUser);

        CityUser Find(Func<CityUser, bool> predicate);
    }
}
