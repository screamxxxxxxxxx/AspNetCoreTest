﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Weather.DAL.Repository.Interfaces
{
    public interface IRepository<TEntity, TContext>
    {
        TContext Context { get; }

        IQueryable<TEntity> GetAllEntities();

        IQueryable<TEntity> Filter(Func<TEntity, bool> predicate);

        void AddEntity(TEntity entity);

        void UpdateEntity(TEntity entity);

        void DeleteEntity(TEntity entity);

        void SaveChanges();
    }
}
