﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Weather.DAL.Repository.Interfaces
{
    public interface IUserRepository
    {
        IdentityUser GetUserWithNameByEmail(string email);

        IEnumerable<IdentityUser> GetAllUsers();
    }
}
