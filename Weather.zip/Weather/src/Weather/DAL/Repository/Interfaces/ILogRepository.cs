﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.DAL.DbModels;

namespace Weather.DAL.Repository.Interfaces
{
    public interface ILogRepository
    {
        void AddLog(Log log);

        IEnumerable<Log> GetAllLogs();
    }
}
