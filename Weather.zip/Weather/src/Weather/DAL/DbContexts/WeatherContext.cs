﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Weather.DAL.DbModels;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace Weather.DAL.DbContexts
{
    public class WeatherContext : IdentityDbContext<IdentityUser> 
    {
        public DbSet<City> Cities { get; set; }

        public DbSet<CityUser> CityUsers { get; set; }

        public DbSet<Log> Logs { get; set; }

        public WeatherContext(DbContextOptions<WeatherContext> options) : base(options)
        {
           
        }
    }
}
