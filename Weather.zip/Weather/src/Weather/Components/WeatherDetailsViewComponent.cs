﻿using Weather.Resources;
using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.Services.Models;
using Microsoft.Extensions.Localization;

namespace Weather.Components
{
    public class WeatherDetailsViewComponent : ViewComponent
    {
        private IStringLocalizer<WeatherDetailsViewComponent> localizer;
        public WeatherDetailsViewComponent(IStringLocalizer<WeatherDetailsViewComponent> localizer)
        {
            this.localizer = localizer;
        }

        public HtmlString Invoke(CityWeatherInfo info)
        {           
            var htmStr = new HtmlString($"<div>{localizer["Temp"]}: {info.temp}, {localizer["MaxTemp"]}: {info.temp_max}, {localizer["TempMin"]}: {info.temp_min}, {localizer["Pressure"]}: {info.pressure}</div>");
            return htmStr;
        }
    }
}
