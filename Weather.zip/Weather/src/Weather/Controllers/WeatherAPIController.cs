﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Weather.Services.Models;
using Weather.Services.Interfaces;
using Microsoft.Extensions.Caching.Memory;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace Weather.Controllers
{
    [Route("api/[controller]/[action]")]
    public class WeatherAPIController : Controller
    {
        private IWeatherAPIService weatherService;
        private IMemoryCache cache;

        public WeatherAPIController(IWeatherAPIService weatherService, IMemoryCache cache)
        {
            this.cache = cache;
            this.weatherService = weatherService;
        }

        [HttpGet("{name}")]
       public async Task<CityWeatherInfo> GetWeatherInCity(string name)
       {
            CityWeatherInfo info = null;

            if(!this.cache.TryGetValue(name, out info))
            {
                info = await this.weatherService.GetWeatherInCity(name);
                this.cache.Set(name, info, new MemoryCacheEntryOptions()
                    .SetPriority(CacheItemPriority.High)
                    .SetAbsoluteExpiration(TimeSpan.FromHours(1))
                    );
            }

            return info;
       }
    }
}
