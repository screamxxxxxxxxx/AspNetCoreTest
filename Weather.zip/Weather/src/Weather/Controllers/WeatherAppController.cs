﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Weather.Services.Models;
using Weather.Services.Interfaces;
using Microsoft.AspNetCore.Mvc.Routing;
using Weather.Helper;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace Weather.Controllers
{
    [Authorize]
    public class WeatherAppController : Controller
    {
        private UserManager<IdentityUser> userManager;
        private IUserService userService;     

        public WeatherAppController(UserManager<IdentityUser> userManager, IUserService userService)
        {
            this.userService = userService;
            this.userManager = userManager;
        }

        // GET: /<controller>/
        public async Task<IActionResult> Index()
        {          
            var userID = (await this.userManager.GetUserAsync(User)).Id;

            var model = new CitiesListForUserModel();          
 
            model.AssignedCities = this.userService.GetAssignedUserCities(userID).Select(x => x.Name).ToList();

            model.AvaliableCities = this.userService.GetAvaliableForAssignCitiesForUSer(userID).Select(x => x.Name).ToList();

            return View(model);
        }       

        public async Task<ActionResult> UnsubscribeFromCity(string name)
        {
            var userID = (await this.userManager.GetUserAsync(User)).Id;

            this.userService.UnSubscribeFromCity(name, userID);

            return RedirectToAction("Index");
        }

        public async Task<ActionResult> SubscribeToCity(string name)
        {
            var userID = (await this.userManager.GetUserAsync(User)).Id;

            this.userService.SubscribeToCity(name, userID);

            return RedirectToAction("Index");
        }
        
        [HttpPost]
        public ActionResult RenderWeatherDataView([FromBody]CityWeatherInfo data)
        {
            return PartialView("RenderWeatherDataView", data);
        }      
    }
}
