﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Weather.DAL.Repository.Interfaces;
using Weather.Services.Logger;

namespace Weather.Extentions
{
    public static class ILoggerFactoryExt
    {
        public static ILoggerFactory AddDbLogger(this ILoggerFactory factory, ILogRepository repository)
        {
            factory.AddProvider(new DbLoggerProvider(repository));
            return factory;
        }
    }
}
