﻿
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Weather.DAL.DbContexts;
using Weather.DAL.Initalizer;
using Weather.Helper;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Weather.Services.Interfaces;
using Weather.Services;
using Weather.DAL.Repository.Interfaces;
using Weather.DAL.Repository;
using Weather.Services.Logger;
using Weather.Extentions;
using System;
using System.Globalization;
using Microsoft.AspNetCore.Localization;
using Microsoft.Extensions.Options;

namespace Weather
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();

            if (env.IsDevelopment())
            {
                builder.AddUserSecrets();
                // This will push telemetry data through Application Insights pipeline faster, allowing you to view results immediately.
                builder.AddApplicationInsightsSettings(developerMode: true);
            }

            this.env = env;
            Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; }

        public IHostingEnvironment env { get; set; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddApplicationInsightsTelemetry(Configuration);
       

            string dbParam = "!mySql";

            if(CommandLineParamsHolder.Args != null && CommandLineParamsHolder.Args.Length > 0)
            {

                var indexOfDbParam = Array.IndexOf(CommandLineParamsHolder.Args, "db");

                if(indexOfDbParam >= 0 && CommandLineParamsHolder.Args.Length >= indexOfDbParam + 2)
                {
                    dbParam = CommandLineParamsHolder.Args[indexOfDbParam + 1];
                }
            }

            var connectionName = ConnentionStringNameHelper.GetConnectionStringName(dbParam);  

            string connection = Configuration.GetConnectionString(connectionName);

            if (env.IsDevelopment())
            {
                connection = Configuration[connectionName];               
            }
                   
            if (connectionName == "SqlConnection")
            {
                services.AddDbContext<WeatherContext>(options => {          
                    options.UseSqlServer(connection);
                });                                        
            }
            else
            {               
                services.AddDbContext<WeatherContext>(options => options.UseMySql(connection));
             
            }

            services.AddScoped<IDbInitializer, SqlDbInitalizer>();

            services.AddIdentity<IdentityUser, IdentityRole>()
                    .AddEntityFrameworkStores<WeatherContext>()
                    .AddDefaultTokenProviders();

            services.AddScoped<IUsersCitiesRepository, CityUserRepository<WeatherContext>>();

            services.AddScoped<IUserRepository, UserRepository<WeatherContext>>();

            services.AddScoped<ICitiesRepository, CityRepository<WeatherContext>>();

            services.AddScoped<ILogRepository, LogRepository<WeatherContext>>();

            // Add framework services.
            services.AddApplicationInsightsTelemetry(Configuration);

            services.AddScoped<IEmailSender, EmailSender>();

            services.AddScoped<IUserService, UserService>();                     

            services.AddScoped<IWeatherAPIService, WeatherService>();

            services.AddMemoryCache();

            services.Configure<RequestLocalizationOptions>(
            opts =>
            {
                var supportedCultures = new[]
                {
                new CultureInfo("en"),
                new CultureInfo("ru"),
            };

                opts.DefaultRequestCulture = new RequestCulture("en");
                // Formatting numbers, dates, etc.
                opts.SupportedCultures = supportedCultures;
                // UI strings that we have localized.
                opts.SupportedUICultures = supportedCultures;
            });

            services.AddLocalization(opts => { opts.ResourcesPath = "Resources"; });
            
            services.AddMvc().AddViewLocalization().AddDataAnnotationsLocalization(); 
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory, ILogRepository logRepository, IDbInitializer dbInitializer)
        {          
            loggerFactory.AddDbLogger(logRepository);
        
            app.UseDeveloperExceptionPage();

            app.UseApplicationInsightsExceptionTelemetry();

            var options = app.ApplicationServices.GetService<IOptions<RequestLocalizationOptions>>();

            app.UseRequestLocalization(options.Value);

            app.UseStaticFiles();

            app.UseIdentity();

            app.UseMvc(routes =>
            {              
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });

            this.env = env;

            dbInitializer.Seed(app.ApplicationServices, Configuration).Wait();
        }
    }
}
