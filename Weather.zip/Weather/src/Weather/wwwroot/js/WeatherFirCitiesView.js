﻿
function SetWeatherData(dataToSend, urlWeatherView)
{
    $.ajax({
        url: urlWeatherView,
        contentType: "application/json",
        method: "Post",
        data: JSON.stringify(dataToSend),      
        success: function (dataRecieved) {
            $("#weatherContent").html(dataRecieved);
        }
    })
}

function GetWeatherForCity(urlApi, urlWeatherView)
{
    $.ajax({
        url: urlApi,
        contentType: "application/json",
        method: "Get",
        success: function (data) {
            SetWeatherData(data, urlWeatherView);
        }
    })
}